ECD per-entity seed export, built 2026-10-22 (IST) from rvkmar/ecd-ai main via GitHub (read-only).
No seed, generator or migration script was run, and nothing was written to any app db.json or Mongo.

Each record has _origin and _sources fields:
  _origin = "screenshot-test-fixture": these records match the screenshots in PRs #78 to #84. The day145g to day145k handoffs say each
    cloud-agent VM ran DB_MODE=json with a throwaway JSON store (ECD_DB_FILE, the same file as the user store), signed in as admin1,
    and loaded it with these unit-test fixture records. No committed seed script was used. Sources:
    src/components/designPatterns/__tests__/designPatternTabFixture.js   (day145g manage tabs: 3 patterns, 3 analyses, 2 task models)
    src/components/domainAnalyses/__tests__/domainAnalysisTabFixture.js
    src/components/templates/__tests__/templateTabFixture.js             (day145h: 3 templates, 2 task models)
    src/components/assemblyModels/__tests__/assemblyTabFixture.js         (day145i: 5 assembly models, 2 task models)
    src/components/qMatrix/__tests__/diagnosticDesignTabFixture.js        (day145j: 5 diagnostic designs)
    src/components/presentationModels/__tests__/presentationTabFixture.js (day145k: 5 presentation models, 2 task models, 3 templates)
    The fixtures reuse ids (for example tm-plant) with different contents, so records are kept per fixture file and not merged.
  _origin = "repo-sample": the importable sample packs in samples/ (sample-*.json and the Newtonian mechanics pack).
qMatrixModels holds diagnostic designs and Q-matrices. Calibration samples and sample-users.json are left out on purpose.
The large synthetic dataset (1000+ items, 400+ sessions) comes from server/fixtures/productionShaped/generate.js. It was not run.
